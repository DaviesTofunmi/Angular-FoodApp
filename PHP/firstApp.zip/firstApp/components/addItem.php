<?php
include("../database/connectdb.php");

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Accept, Origin, X-Requested-With");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE");

session_start();

// Check if the request is a POST request
if (isset($_POST['name']) && isset($_POST['price']) && isset($_POST['category'])) {
    // Get the uploaded file
    $product_img = $_POST['image'];

    // Get the other product details from the request
    $product_name = $_POST['name'];
    $product_price = $_POST['price'];
    $product_category = $_POST['category'];
    $product_desc = $_POST['desc'];
    $quantity= $_POST['quantity'];
   
// Use this incase file path is wrong
    // $img_path = "images/";
    // if (!file_exists($img_path)) {
    //     mkdir($img_path, 0777, true);
    // }

//    $img_path = "images/";
//     if (!file_exists($img_path)) {
//         mkdir($img_path, 0777, true);
//     }

  
//     $file = $img_path.basename($product_img['name']);

    // Insert the product details into the database
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "INSERT INTO cart (product_name, product_price, product_category, product_img, product_desc, quantity) VALUES ('$product_name', '$product_price', '$product_category', '$product_img', '$product_desc', '$quantity')";
    if (mysqli_query($conn, $sql)) {
      
        echo json_encode(['message' => 'Added item to cart']);
        exit;
    } else {
        echo json_encode(['message' => 'Failed']);
        exit;
    }
} 

?>