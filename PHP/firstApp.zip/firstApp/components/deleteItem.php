<?php
include("../database/connectdb.php");

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Accept, Origin, X-Requested-With");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE");

session_start();

// Check if the request is a POST request
if (isset($_POST['name']) ) {
    // Get the uploaded file


    // Get the other product details from the request
    $product_name = $_POST['name'];
  
  

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $sql = "DELETE FROM cart WHERE product_name = '$product_name'";
    $response= mysqli_query($conn, $sql);
   
    if ($response) {
        echo json_encode([
            'message' => 'Item Deleted',
           
          ]);
        
      

        
        }
        else {
            echo json_encode(['message' => 'Delete action failed']);

        }
     
}
    ?>